GUI/SETTINGS
============
Purpose:
- Data / assets under: gui/settings

Observed in extracted data:
- 2 text-like file(s) detected in this directory.
