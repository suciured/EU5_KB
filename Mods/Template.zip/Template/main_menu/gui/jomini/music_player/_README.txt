GUI/JOMINI/MUSIC_PLAYER
=======================
Purpose:
- Data / assets under: gui/jomini/music_player

Observed in extracted data:
- 2 text-like file(s) detected in this directory.
