GUI/ANIMATIONS
==============
Purpose:
- Data / assets under: gui/animations

Observed in extracted data:
- 0 text-like file(s) detected in this directory.
