GUI/DEBUG
=========
Purpose:
- Data / assets under: gui/debug

Observed in extracted data:
- 8 text-like file(s) detected in this directory.
