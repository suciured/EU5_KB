GUI
===
Purpose:
- Data / assets under: gui

Observed in extracted data:
- 23 text-like file(s) detected in this directory.
