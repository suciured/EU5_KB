GUI/OBJECT_EXPLORER
===================
Purpose:
- Data / assets under: gui/object_explorer

Observed in extracted data:
- 1 text-like file(s) detected in this directory.
