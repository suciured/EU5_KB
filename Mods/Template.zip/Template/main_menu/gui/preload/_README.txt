GUI/PRELOAD
===========
Purpose:
- Data / assets under: gui/preload

Observed in extracted data:
- 1 text-like file(s) detected in this directory.
