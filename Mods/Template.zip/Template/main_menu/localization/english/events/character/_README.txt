LOCALIZATION/ENGLISH/EVENTS/CHARACTER
=====================================
Purpose:
- Data / assets under: localization/english/events/character

Observed in extracted data:
- 8 text-like file(s) detected in this directory.
