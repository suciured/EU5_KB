LOCALIZATION/ENGLISH/EVENTS/DISASTERS
=====================================
Purpose:
- Data / assets under: localization/english/events/disasters

Observed in extracted data:
- 33 text-like file(s) detected in this directory.
