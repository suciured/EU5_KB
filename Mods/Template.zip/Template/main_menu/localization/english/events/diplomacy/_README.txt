LOCALIZATION/ENGLISH/EVENTS/DIPLOMACY
=====================================
Purpose:
- Data / assets under: localization/english/events/diplomacy

Observed in extracted data:
- 7 text-like file(s) detected in this directory.
