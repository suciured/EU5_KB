LOCALIZATION/ENGLISH/EVENTS/COLONIZATION
========================================
Purpose:
- Data / assets under: localization/english/events/colonization

Observed in extracted data:
- 6 text-like file(s) detected in this directory.
