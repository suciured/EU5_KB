LOCALIZATION/ENGLISH/EVENTS/DHE
===============================
Purpose:
- Data / assets under: localization/english/events/DHE

Observed in extracted data:
- 132 text-like file(s) detected in this directory.
