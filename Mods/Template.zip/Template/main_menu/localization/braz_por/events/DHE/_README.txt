LOCALIZATION/BRAZ_POR/EVENTS/DHE
================================
Purpose:
- Data / assets under: localization/braz_por/events/DHE

Observed in extracted data:
- 132 text-like file(s) detected in this directory.
