LOCALIZATION/BRAZ_POR/EVENTS/ESTATES
====================================
Purpose:
- Data / assets under: localization/braz_por/events/estates

Observed in extracted data:
- 6 text-like file(s) detected in this directory.
