LOCALIZATION/BRAZ_POR/EVENTS/DISASTERS
======================================
Purpose:
- Data / assets under: localization/braz_por/events/disasters

Observed in extracted data:
- 33 text-like file(s) detected in this directory.
