LOCALIZATION/BRAZ_POR/EVENTS/ECONOMY
====================================
Purpose:
- Data / assets under: localization/braz_por/events/economy

Observed in extracted data:
- 10 text-like file(s) detected in this directory.
