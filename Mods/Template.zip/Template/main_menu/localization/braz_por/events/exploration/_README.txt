LOCALIZATION/BRAZ_POR/EVENTS/EXPLORATION
========================================
Purpose:
- Data / assets under: localization/braz_por/events/exploration

Observed in extracted data:
- 2 text-like file(s) detected in this directory.
