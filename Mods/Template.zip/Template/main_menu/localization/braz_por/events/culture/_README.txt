LOCALIZATION/BRAZ_POR/EVENTS/CULTURE
====================================
Purpose:
- Data / assets under: localization/braz_por/events/culture

Observed in extracted data:
- 5 text-like file(s) detected in this directory.
