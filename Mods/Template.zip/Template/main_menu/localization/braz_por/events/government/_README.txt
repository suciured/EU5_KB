LOCALIZATION/BRAZ_POR/EVENTS/GOVERNMENT
=======================================
Purpose:
- Data / assets under: localization/braz_por/events/government

Observed in extracted data:
- 17 text-like file(s) detected in this directory.
