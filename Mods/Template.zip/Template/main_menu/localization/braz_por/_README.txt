LOCALIZATION/BRAZ_POR
=====================
Purpose:
- Data / assets under: localization/braz_por

Observed in extracted data:
- 106 text-like file(s) detected in this directory.
