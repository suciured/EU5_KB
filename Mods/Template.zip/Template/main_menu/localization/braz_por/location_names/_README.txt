LOCALIZATION/BRAZ_POR/LOCATION_NAMES
====================================
Purpose:
- Data / assets under: localization/braz_por/location_names

Observed in extracted data:
- 62 text-like file(s) detected in this directory.
