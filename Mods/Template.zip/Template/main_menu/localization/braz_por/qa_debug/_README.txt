LOCALIZATION/BRAZ_POR/QA_DEBUG
==============================
Purpose:
- Data / assets under: localization/braz_por/qa_debug

Observed in extracted data:
- 2 text-like file(s) detected in this directory.
