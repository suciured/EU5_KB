COMMON/FLAG_DEFINITIONS
=======================
Purpose:
- Data / assets under: common/flag_definitions

Observed in extracted data:
- 1 text-like file(s) detected in this directory.
