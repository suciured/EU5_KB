COMMON/SCRIPTED_LISTS
=====================
Purpose:
- Data / assets under: common/scripted_lists

Observed in extracted data:
- 0 text-like file(s) detected in this directory.
