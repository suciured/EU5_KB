COMMON/NAMED_COLORS
===================
Purpose:
- Data / assets under: common/named_colors

Observed in extracted data:
- 3 text-like file(s) detected in this directory.
