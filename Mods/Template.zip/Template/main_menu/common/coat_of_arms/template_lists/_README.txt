COMMON/COAT_OF_ARMS/TEMPLATE_LISTS
==================================
Purpose:
- Data / assets under: common/coat_of_arms/template_lists

Observed in extracted data:
- 5 text-like file(s) detected in this directory.
