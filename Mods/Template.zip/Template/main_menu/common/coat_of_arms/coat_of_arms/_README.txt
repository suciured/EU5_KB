COMMON/COAT_OF_ARMS/COAT_OF_ARMS
================================
Purpose:
- Data / assets under: common/coat_of_arms/coat_of_arms

Observed in extracted data:
- 9 text-like file(s) detected in this directory.
