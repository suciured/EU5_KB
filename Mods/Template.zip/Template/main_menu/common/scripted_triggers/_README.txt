COMMON/SCRIPTED_TRIGGERS
========================
Purpose:
- Data / assets under: common/scripted_triggers

Observed in extracted data:
- 2 text-like file(s) detected in this directory.
