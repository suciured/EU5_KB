EVENTS
======
Purpose:
- Event scripts under: events

Observed in extracted base data:
- 25 event file(s).
