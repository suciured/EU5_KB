EVENTS/RELIGION
===============
Purpose:
- Event scripts under: events/religion

Observed in extracted base data:
- 28 event file(s).
