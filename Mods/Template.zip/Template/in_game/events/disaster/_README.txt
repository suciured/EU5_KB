EVENTS/DISASTER
===============
Purpose:
- Event scripts under: events/disaster

Observed in extracted base data:
- 33 event file(s).
