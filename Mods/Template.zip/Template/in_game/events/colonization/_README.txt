EVENTS/COLONIZATION
===================
Purpose:
- Event scripts under: events/colonization

Observed in extracted base data:
- 6 event file(s).
