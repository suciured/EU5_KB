EVENTS/CULTURE
==============
Purpose:
- Event scripts under: events/culture

Observed in extracted base data:
- 5 event file(s).
