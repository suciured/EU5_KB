EVENTS/SITUATIONS
=================
Purpose:
- Event scripts under: events/situations

Observed in extracted base data:
- 23 event file(s).
