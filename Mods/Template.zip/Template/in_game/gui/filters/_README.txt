GUI/FILTERS
===========
Purpose:
- UI definitions under: gui/filters

Observed in extracted base data:
- 18 GUI/text file(s) detected in this directory.
