GUI/PANELS/TRADE
================
Purpose:
- UI definitions under: gui/panels/trade

Observed in extracted base data:
- 3 GUI/text file(s) detected in this directory.
