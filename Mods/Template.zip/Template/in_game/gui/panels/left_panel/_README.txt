GUI/PANELS/LEFT_PANEL
=====================
Purpose:
- UI definitions under: gui/panels/left_panel

Observed in extracted base data:
- 1 GUI/text file(s) detected in this directory.
