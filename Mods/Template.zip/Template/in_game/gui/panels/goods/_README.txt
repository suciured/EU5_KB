GUI/PANELS/GOODS
================
Purpose:
- UI definitions under: gui/panels/goods

Observed in extracted base data:
- 2 GUI/text file(s) detected in this directory.
