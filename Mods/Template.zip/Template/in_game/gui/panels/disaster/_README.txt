GUI/PANELS/DISASTER
===================
Purpose:
- UI definitions under: gui/panels/disaster

Observed in extracted base data:
- 35 GUI/text file(s) detected in this directory.
