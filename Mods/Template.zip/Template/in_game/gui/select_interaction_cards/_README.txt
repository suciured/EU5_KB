GUI/SELECT_INTERACTION_CARDS
============================
Purpose:
- UI definitions under: gui/select_interaction_cards

Observed in extracted base data:
- 3 GUI/text file(s) detected in this directory.
