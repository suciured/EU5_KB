GUI/JOMINI
==========
Purpose:
- UI definitions under: gui/jomini

Observed in extracted base data:
- 1 GUI/text file(s) detected in this directory.
