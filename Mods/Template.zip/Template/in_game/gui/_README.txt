GUI
===
Purpose:
- UI definitions under: gui

Observed in extracted base data:
- 154 GUI/text file(s) detected in this directory.
