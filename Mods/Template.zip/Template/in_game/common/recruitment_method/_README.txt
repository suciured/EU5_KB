COMMON/recruitment_method
============
Purpose:
- Definitions for: recruitment_method

Observed in extracted base data:
- 3 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
