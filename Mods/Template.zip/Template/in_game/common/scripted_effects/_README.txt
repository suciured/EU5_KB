COMMON/scripted_effects
============
Purpose:
- Definitions for: scripted_effects

Observed in extracted base data:
- 14 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
