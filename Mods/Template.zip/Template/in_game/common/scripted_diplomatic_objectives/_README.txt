COMMON/scripted_diplomatic_objectives
============
Purpose:
- Definitions for: scripted_diplomatic_objectives

Observed in extracted base data:
- 3 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
