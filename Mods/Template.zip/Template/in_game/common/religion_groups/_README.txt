COMMON/religion_groups
============
Purpose:
- Definitions for: religion_groups

Observed in extracted base data:
- 1 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
