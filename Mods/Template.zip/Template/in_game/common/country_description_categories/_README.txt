COMMON/country_description_categories
============
Purpose:
- Definitions for: country_description_categories

Observed in extracted base data:
- 2 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
