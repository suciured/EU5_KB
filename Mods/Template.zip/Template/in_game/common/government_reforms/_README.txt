COMMON/government_reforms
============
Purpose:
- Definitions for: government_reforms

Observed in extracted base data:
- 7 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
