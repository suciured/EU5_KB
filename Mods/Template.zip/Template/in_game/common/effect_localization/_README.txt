COMMON/effect_localization
============
Purpose:
- Definitions for: effect_localization

Observed in extracted base data:
- 31 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
