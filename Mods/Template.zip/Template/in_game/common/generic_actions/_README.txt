COMMON/generic_actions
============
Purpose:
- Definitions for: generic_actions

Observed in extracted base data:
- 88 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
