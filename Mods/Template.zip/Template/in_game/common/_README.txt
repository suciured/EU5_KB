COMMON
======
Core gameplay definition layer.
Most folders here define data tables / script blocks.
Prefer additive changes and new keys over overwriting base files.
