COMMON/missions
============
Purpose:
- Definitions for: missions

Observed in extracted base data:
- 12 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
