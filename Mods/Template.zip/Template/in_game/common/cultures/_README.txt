COMMON/cultures
============
Purpose:
- Definitions for: cultures

Observed in extracted base data:
- 51 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
