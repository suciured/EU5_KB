COMMON/international_organization_payments
============
Purpose:
- Definitions for: international_organization_payments

Observed in extracted base data:
- 6 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
