COMMON/casus_belli
============
Purpose:
- Definitions for: casus_belli

Observed in extracted base data:
- 62 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
