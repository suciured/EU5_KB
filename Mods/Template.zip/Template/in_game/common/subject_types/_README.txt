COMMON/subject_types
============
Purpose:
- Definitions for: subject_types

Observed in extracted base data:
- 17 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
