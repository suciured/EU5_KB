COMMON/unit_abilities
============
Purpose:
- Definitions for: unit_abilities

Observed in extracted base data:
- 15 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
