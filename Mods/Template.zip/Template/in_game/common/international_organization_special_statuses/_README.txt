COMMON/international_organization_special_statuses
============
Purpose:
- Definitions for: international_organization_special_statuses

Observed in extracted base data:
- 10 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
