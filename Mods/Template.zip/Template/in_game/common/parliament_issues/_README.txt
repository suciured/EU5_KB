COMMON/parliament_issues
============
Purpose:
- Definitions for: parliament_issues

Observed in extracted base data:
- 9 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
