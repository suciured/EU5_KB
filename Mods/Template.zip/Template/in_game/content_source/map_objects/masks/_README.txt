CONTENT_SOURCE/MAP_OBJECTS/MASKS
================================
Purpose:
- Content source data under: content_source/map_objects/masks

Observed in extracted base data:
- 0 file(s).
