SETUP/COUNTRIES
===============
Purpose:
- Setup definitions under: setup/countries

Observed in extracted base data:
- 45 text file(s) detected in this directory.
